
package com.example.idleclicker

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private var score = 0
    private var autoPlay = false
    private var interval: Long = 1000
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var scoreText: TextView

    private val autoRunnable = object : Runnable {
        override fun run() {
            if (autoPlay) {
                score++
                updateUI()
                handler.postDelayed(this, interval)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        scoreText = findViewById(R.id.scoreText)
        val clickButton = findViewById<Button>(R.id.clickButton)
        val autoButton = findViewById<Button>(R.id.autoButton)
        val speedButton = findViewById<Button>(R.id.speedButton)

        clickButton.setOnClickListener {
            score++
            updateUI()
        }

        autoButton.setOnClickListener {
            autoPlay = !autoPlay
            if (autoPlay) {
                handler.post(autoRunnable)
                autoButton.text = "Stop Auto"
            } else {
                autoButton.text = "Start Auto"
            }
        }

        speedButton.setOnClickListener {
            interval = when (interval) {
                1000L -> 500L
                500L -> 200L
                else -> 1000L
            }
        }

        updateUI()
    }

    private fun updateUI() {
        scoreText.text = "Points: $score"
    }
}
